"""this file can only be used by spconv developer for now. 
the "tensorpc" isn't a open source project.
"""

import tensorpc 

from tensorpc.apps.flow.flowapp import App


class TestApp(App):
    pass