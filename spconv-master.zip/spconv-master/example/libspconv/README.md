# libspconv

libspconv + pybindings = "core_cc.so" in spconv python package.

## libspconv Example

run ```run_build.sh``` to get ```libspconv.so```.

see [inference code example](main.cu)

## libspconv API

currently not available, but you can check python code to understand how to use C++ apis, spconv python and libspconv use same c++ code.