from .basic import bench_basic, bench_large

import fire

if __name__ == "__main__":
    fire.Fire()
